from PyQt6.QtCore import QTimer, QTime
from PyQt6.QtMultimedia import QMediaPlayer

def spremeniglas(self, vrednost):
    self.audioOutput.setVolume(vrednost / 100)

def pohitrigumb(self):
    self.trenutna = self.mediaPlayer.playbackRate()
    self.mediaPlayer.setPlaybackRate(2)

def nehajpohitrigumb(self):
    self.mediaPlayer.setPlaybackRate(self.trenutna)

def predvajajnazaj(self):
    if self.mediaPlayer.position() > 0:
        self.mediaPlayer.setPosition(self.mediaPlayer.position() - 100)

def nazajgumb(self):
    self.trenutna = self.mediaPlayer.playbackRate()
    self.mediaPlayer.setPlaybackRate(2)
    self.timer = QTimer()
    self.timer.timeout.connect(self.predvajajnazaj)
    self.timer.start(100)
    self.mediaPlayer.pause()

def nehajnazajgumb(self):
    if hasattr(self, 'timer'):
        self.timer.stop()
    self.mediaPlayer.setPlaybackRate(self.trenutna)
    self.mediaPlayer.play()

def preskocipetino(self):
    dolzina = self.mediaPlayer.duration()
    if dolzina > 0:
        trenutna_pozicija = self.mediaPlayer.position()
        skok = dolzina // 5
        novapoz = min(trenutna_pozicija + skok, dolzina)
        self.mediaPlayer.setPosition(novapoz)

def spremhit(self):
    hitrost = float(self.hitrosti.currentText().replace("x", ""))
    self.mediaPlayer.setPlaybackRate(hitrost)

def povecajfsc(self):
    if self.isMaximized():
        self.showNormal()
    else:
        self.showMaximized()

def changepos(self, pos):
    if not self.slider.isSliderDown():
        self.slider.setValue(pos)
        time = QTime(0, 0, 0).addMSecs(pos)
        self.cas.setText(time.toString("hh:mm:ss"))

def predvajajvideo(self):
    if self.mediaPlayer.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
        self.mediaPlayer.pause()
    else:
        self.mediaPlayer.play()

def prviframe(self, status):
    if status == QMediaPlayer.MediaStatus.LoadedMedia:
        if self.mediaPlayer.position() == 0:
            self.mediaPlayer.setPosition(1)
            self.mediaPlayer.pause()