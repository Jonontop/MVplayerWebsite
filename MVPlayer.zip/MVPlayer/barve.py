#funk. za posodobit barve
def posodobi(self, barva):
    self.odpri.setStyleSheet(f"""
        QPushButton {{
            background-color: transparent;
            color: {barva};
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            padding: 6px 12px;
        }}
        QPushButton:hover {{
            background-color: {barva};
            color: white;
            padding: 5px 11px;
        }}
        QPushButton:pressed {{
            background-color: {barva};
        }}""")

    self.slider.setStyleSheet(f"""
        QSlider::groove:horizontal {{
            background: 255;
            height: 8px;
            border-radius: 4px;
        }}
        QSlider::handle:horizontal {{
            background: {barva};
            border: 2px solid #cc7a00;
            width: 18px;
            height: 18px;
            margin: -5px 0;
            border-radius: 9px;
        }}
        QSlider::sub-page:horizontal {{
            background: {barva};
            border-radius: 4px;
        }}
        QSlider::add-page:horizontal {{
            background: #222;
            border-radius: 4px;
        }}""")
        
    self.url.setStyleSheet(f"""
        QLineEdit {{
            background-color: #222;
            color: {barva};
            border: 2px solid {barva};
            padding: 5px;
            border-radius: 5px;
        }}""")
        
    self.cas.setStyleSheet(f"color: {barva}; font-size: 14px; font-weight: bold;")
    self.vrsta.setStyleSheet(f"color:{barva}; font-size:14px;")
    
    self.dmp3.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}""")
    
    self.dmp4.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}""")
    
    self.predvajaj.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}
        QPushButton:pressed {{
            background-color: #333;
            border: 2px solid black;
        }}""")
    
    self.predvajaj.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}
        QPushButton:pressed {{
            background-color: #333;
            border: 2px solid black;
        }}""")
    
    self.ffrwrd.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}
        QPushButton:pressed {{
            background-color: #333;
            border: 2px solid black;
        }}""")
    
    self.nazaj.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}
        QPushButton:pressed {{
            background-color: #333;
            border: 2px solid black;
        }}""")
    
    self.prespet.setStyleSheet(f"""
        QPushButton {{
            background-color: {barva};
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }}
        QPushButton:hover {{
            background-color: {barva};
        }}
        QPushButton:pressed {{
            background-color: #333;
            border: 2px solid black;
        }}""")
    
    self.barvegumb.setStyleSheet(f"""
        QComboBox {{
            background-color: {barva};
            color: black;
            font-size: 14px;
            padding: 3px;
            border-radius: 5px;
            min-width:60px;
        }}
        QComboBox::drop-down {{
            border: 0px;
        }}
        QComboBox QAbstractItemView {{
            background-color: black;
            color: {barva};
            selection-background-color: {barva};
        }}""")
    
    self.hitrosti.setStyleSheet(f"""
        QComboBox {{
            background-color: {barva};
            color: black;
            font-size: 14px;
            padding: 3px;
            border-radius: 5px;
            max-width:48px;
        }}
        QComboBox::drop-down {{
            border: 0px;
        }}
        QComboBox QAbstractItemView {{
            background-color: black;
            color: {barva};
            selection-background-color: {barva};
        }}""")
    
    if self.nekipac == 1:
        self.loopgumb.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width:60px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
        
        self.nasledngumb.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width: 20px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
            
        self.prejsngumb.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width: 20px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
            
        self.randomgumb.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width: 20px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
        
        self.shuffle.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width: 20px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
        
        self.refreshrgumb.setStyleSheet(f"""
            QPushButton {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
                max-width: 25px;
            }}
            QPushButton:hover {{
                background-color: {barva};
            }}
            QPushButton:pressed {{
                background-color: {barva};
            }}""")
        
        self.radiocombox.setStyleSheet(f"""
            QComboBox {{
                background-color: {barva};
                color: black;
                font-size: 14px;
                padding: 3px;
                border-radius: 5px;
                min-width: 150px;
            }}
            QComboBox::drop-down {{
                border: 0px;
            }}
            QComboBox QAbstractItemView {{
                background-color: black;
                color: {barva};
                selection-background-color: {barva};
            }}""")