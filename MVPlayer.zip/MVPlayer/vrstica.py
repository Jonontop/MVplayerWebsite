from PyQt6.QtWidgets import QPushButton, QComboBox, QHBoxLayout, QStyle, QCheckBox, QSlider
from PyQt6.QtCore import Qt
import barve, style, radio

def dodajvrstico(self):
    radio.stations(self)
    if self.nekipac == 0:
        #loop gumb
        if self.loopprzg==False:
            self.loopgumb = QPushButton("Loop Off")
        else:
            self.loopgumb = QPushButton("Loop On")
        self.loopgumb.clicked.connect(self.toggleloop)
        self.loopgumb.setStyleSheet(""" ... """)
        self.mediaPlayer.positionChanged.connect(self.checkloop)
        style.loopgumb(self)

        #nasledn video 
        self.nasledngumb = QPushButton(">")
        self.nasledngumb.clicked.connect(lambda: self.nasledn(1))
        style.nasledngumb(self)
        
        #prejsn video 
        self.prejsngumb = QPushButton("<")
        self.prejsngumb.clicked.connect(lambda: self.nasledn(-1))
        style.prejsngumb(self)
        
        #random (za 1 pesm -shuffle je dol)
        self.randomgumb = QPushButton("🎲")
        self.randomgumb.clicked.connect(self.random)
        style.randomgumb(self)
        
        #barve pac un kakrkol dropdown
        self.barvegumb=QComboBox()
        self.barvegumb.addItems(["cyan", "green", "red", "white", "yellow", "orange", "blue", "magenta", "purple", "pink", "gray", "lime"])
        self.barvegumb.setCurrentText("orange")
        self.barvegumb.currentTextChanged.connect(lambda barva: barve.posodobi(self, barva))
        style.barvegumb(self)
        
        #kokr pac shuffle
        if hasattr(self, 'shufflemg') and self.shufflemg.randomode:
            self.shuffle = QPushButton("On")
        else:
            self.shuffle = QPushButton("Off")
        self.shuffle.clicked.connect(self.togglerm)
        style.shuffle(self)

        #radio
        self.radiocombox = QComboBox()
        self.radiocombox.addItem("Brez postaje")
        for station in self.radiostations:
            self.radiocombox.addItem(station["name"], station["url"])
        self.radiocombox.currentIndexChanged.connect(self.playr)
        style.radiocombox(self)
        
        #refresh radip
        self.refreshrgumb = QPushButton("⟳")
        self.refreshrgumb.clicked.connect(self.refreshrs)
        style.refreshrgumb(self)
        

        dbox = QHBoxLayout()
        dbox.addWidget(self.radiocombox)
        dbox.addWidget(self.refreshrgumb)
        dbox.addStretch(1)
        dbox.addWidget(self.barvegumb)
        dbox.addWidget(self.loopgumb)
        dbox.addWidget(self.prejsngumb)
        dbox.addWidget(self.randomgumb)
        dbox.addWidget(self.shuffle)
        dbox.addWidget(self.nasledngumb)
        self.layout().insertLayout(1, dbox)
        self.nekipac = 1
        self.vrstica.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowDown))
    else:
        layouti = self.layout().itemAt(1)
        if layouti:
            widget = layouti.widget()
            if widget:
                widget.deleteLater()
            else:
                layouti.layout().deleteLater()

        self.nekipac = 0
        self.vrstica.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowUp))