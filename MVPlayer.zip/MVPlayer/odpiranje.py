from PyQt6.QtWidgets import QFileDialog, QMessageBox
from PyQt6.QtCore import QUrl

def odpridatoteko(self, mediaPlayer, predvajaj, ffrwrd, nazaj, prespet, vrsta):
    imedatoteke, _ = QFileDialog.getOpenFileName(
        self, 
        "Odpri video", 
        "", 
    )   
    if not imedatoteke:
        return  
    try:
        try:
            mediaPlayer.mediaStatusChanged.disconnect(self.prviframe)
        except TypeError:
            pass 
        mediaPlayer.setSource(QUrl.fromLocalFile(imedatoteke))
        predvajaj.setEnabled(True)
        ffrwrd.setEnabled(True)
        nazaj.setEnabled(True)
        prespet.setEnabled(True)
        fileex = imedatoteke.split('.')[-1].upper()
        vrsta.setText(f".{fileex}")
        mediaPlayer.mediaStatusChanged.connect(self.prviframe)  
    except Exception as e:
        QMessageBox.critical(self, "Napaka", f"Napaka pri odpiranju datoteke:\n{str(e)}")