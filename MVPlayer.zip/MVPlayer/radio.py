def stations(self):
    self.radiostations=[
  {
    "bitrate": "128",
    "id": "s106465",
    "img": "http://cdn-profiles.tunein.com/s106465/images/logoq.jpg?t=152604",
    "label": "Tvoji najljubsi hiti",
    "name": "Radio Maxi 90.0",
    "url": "http://live.radio.si/Maxi"
  },
  {
    "bitrate": "128",
    "id": "s106505",
    "img": "http://cdn-profiles.tunein.com/s106505/images/logoq.jpg?t=157433",
    "label": "100% Rock",
    "name": "Radio Bob 87.6",
    "url": "http://live.radiobob.si/Europa05"
  },
  {
    "bitrate": "56",
    "id": "s10248",
    "img": "http://cdn-profiles.tunein.com/s10248/images/logoq.png?t=153779",
    "label": "Smo lokalna radijska...",
    "name": "Radio Fantasy 87.8",
    "url": "http://live2.radioantena.si/Antena-Stajerska"
  },
  {
    "bitrate": "128",
    "id": "s16355",
    "img": "http://cdn-radiotime-logos.tunein.com/s16355q.png",
    "label": "RADIO SALOMON:...",
    "name": "Radio Salomon 87.8",
    "url": "http://195.95.158.131:80/Salomon"
  },
  {
    "bitrate": "128",
    "id": "s10206",
    "img": "http://cdn-profiles.tunein.com/s10206/images/logoq.png?t=154721",
    "label": "ABBA - Chiquitita",
    "name": "Radio Brezice Eu 88.7",
    "url": "http://stream.radiojar.com/a62vxp5uvueuv"
  },
  {
    "bitrate": "128",
    "id": "s176291",
    "img": "http://cdn-radiotime-logos.tunein.com/s176291q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Dolenjska 88.9",
    "url": "http://live1.radio1.si/Radio1NM"
  },
  {
    "bitrate": "128",
    "id": "s48741",
    "img": "http://cdn-radiotime-logos.tunein.com/s48741q.png",
    "label": "Glasbo izbiramo tako, da...",
    "name": "Radio Ptuj 89.8",
    "url": "http://stream.radio-ptuj.si:8000/"
  },
  {
    "bitrate": "128",
    "id": "s232747",
    "img": "http://cdn-radiotime-logos.tunein.com/s232585q.png",
    "label": "Billy Idol - Dancing With Myself",
    "name": "ROCK RADIO SI 107.4",
    "url": "http://stream.radiocenter.si:9034"
  },
  {
    "bitrate": "128",
    "id": "s9615",
    "img": "http://cdn-radiotime-logos.tunein.com/s9615q.png",
    "label": "The Police - Every Breath You Take",
    "name": "Radio 1 89.7",
    "url": "http://live1.radio1.si/Radio1"
  },
  {
    "bitrate": "96",
    "id": "s9666",
    "img": "http://cdn-radiotime-logos.tunein.com/s9666q.png",
    "label": "Slovenian",
    "name": "Radio 1 Bela krajina 89.5",
    "url": "http://live1.radio1.si/Radio1BK"
  },
  {
    "bitrate": "128",
    "id": "s106387",
    "img": "http://cdn-radiotime-logos.tunein.com/s106387q.png",
    "label": "Slovenian",
    "name": "Radio 1 Celje 90.3",
    "url": "http://live1.radio1.si/Radio1CE"
  },
  {
    "bitrate": "128",
    "id": "s273867",
    "img": "http://cdn-radiotime-logos.tunein.com/s273867q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Litija 89.7",
    "url": "http://live1.radio1.si/Radio1LI"
  },
  {
    "bitrate": "128",
    "id": "s176292",
    "img": "http://cdn-radiotime-logos.tunein.com/s176292q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Maribor 107.9",
    "url": "http://live1.radio1.si/Radio1MB"
  },
  {
    "bitrate": "128",
    "id": "s9658",
    "img": "http://cdn-radiotime-logos.tunein.com/s9658q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Obala 93.4",
    "url": "http://live1.radio1.si/Radio1OB"
  },
  {
    "bitrate": "128",
    "id": "s9387",
    "img": "http://cdn-radiotime-logos.tunein.com/s9387q.png",
    "label": "Radio 1 - najbolj poslušan...",
    "name": "Radio 1 Prekmurje 102.1",
    "url": "http://live1.radio1.si/Radio1PR"
  },
  {
    "bitrate": "128",
    "id": "s106535",
    "img": "http://cdn-radiotime-logos.tunein.com/s106535q.png",
    "label": "Vel dobre glasbe",
    "name": "Radio 1 Ptuj 92.3",
    "url": "http://live1.radio1.si/Radio1PT"
  },
  {
    "bitrate": "128",
    "id": "s176288",
    "img": "http://cdn-radiotime-logos.tunein.com/s176288q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Ribnica 89.8",
    "url": "http://live1.radio1.si/Radio1RIB"
  },
  {
    "bitrate": "128",
    "id": "s176290",
    "img": "http://cdn-radiotime-logos.tunein.com/s176290q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Velenje 102.5",
    "url": "http://live1.radio1.si/Radio1VE"
  },
  {
    "bitrate": "128",
    "id": "s106545",
    "img": "http://cdn-radiotime-logos.tunein.com/s106545q.png",
    "label": "Več dobre glasbe",
    "name": "Radio 1 Vrhnika 90.6",
    "url": "http://live1.radio1.si/Radio1VR"
  },
  {
    "bitrate": "32",
    "id": "s262412",
    "img": "http://cdn-radiotime-logos.tunein.com/s262412q.png",
    "label": "Tvoji najljubsi hiti",
    "name": "Radio 2 92.6",
    "url": "http://live.radio2.si/Radio2"
  },
  {
    "bitrate": "128",
    "id": "s106417",
    "img": "http://cdn-radiotime-logos.tunein.com/s106417q.png",
    "label": "Radio narejen za vaša ušesa",
    "name": "Radio Aktual 101.2",
    "url": "http://195.95.158.131:9040/"
  },
  {
    "bitrate": "32",
    "id": "s106523",
    "img": "http://cdn-radiotime-logos.tunein.com/s106523q.png",
    "label": "Slovenian",
    "name": "Radio Antena 105.2",
    "url": "http://live2.infonetmedia.si:8000/Antena"
  },
  {
    "bitrate": "128",
    "id": "s55140",
    "img": "http://cdn-radiotime-logos.tunein.com/s55140q.png",
    "label": "Tvoj radio",
    "name": "Radio Capris 95.6",
    "url": "http://stream01.exit.si:8000/live"
  },
  {
    "bitrate": "128",
    "id": "s221059",
    "img": "http://cdn-radiotime-logos.tunein.com/s16011q.png",
    "label": "Sami hiti",
    "name": "Radio City 99.5",
    "url": "http://stream.radiocity.live:8000/CityMp3128.mp3"
  },
  {
    "bitrate": "128",
    "id": "s9614",
    "img": "http://cdn-radiotime-logos.tunein.com/s9614q.png",
    "label": "Spandau Ballet - Gold",
    "name": "Radio Ekspres 106.4",
    "url": "http://stream2.radioekspres.si:8016/"
  },
  {
    "bitrate": "32",
    "id": "s9953",
    "img": "http://cdn-radiotime-logos.tunein.com/s9953q.png",
    "label": "Sirimo Veselje",
    "name": "Radio Gorenc 93.8",
    "url": "http://stream.radiogorenc.si:8000/radiogorenc.mp3"
  },
  {
    "bitrate": "96",
    "id": "s8967",
    "img": "http://cdn-radiotime-logos.tunein.com/s8967q.png",
    "label": "Vedno Tvoj Hit",
    "name": "Radio Hit 95.6",
    "url": "http://stream02.exit.si:8000/radiohit"
  },
  {
    "bitrate": "32",
    "id": "s9641",
    "img": "http://cdn-radiotime-logos.tunein.com/s9641q.png",
    "label": "music",
    "name": "Radio Kranj 97.3",
    "url": "http://live.radio-kranj.si/Kranj"
  },
  {
    "bitrate": "192",
    "id": "s16015",
    "img": "http://cdn-radiotime-logos.tunein.com/s16015q.png",
    "label": "Slovenian",
    "name": "Radio Krka 106.6",
    "url": "http://93.103.12.127:8000"
  },
  {
    "bitrate": "128",
    "id": "s106458",
    "img": "http://cdn-radiotime-logos.tunein.com/s106458q.png",
    "label": "Slovenian",
    "name": "Radio Kum 98.1",
    "url": "http://195.95.158.131:7010/"
  },
  {
    "bitrate": "192",
    "id": "s9303",
    "img": "http://cdn-radiotime-logos.tunein.com/s9303q.png",
    "label": "Mariborski radio študent (MARS)",
    "name": "Radio MARŠ 95.9",
    "url": "http://frekvenca.eu:8000/radiomars.mp3"
  },
  {
    "bitrate": "32",
    "id": "s10960",
    "img": "http://cdn-radiotime-logos.tunein.com/s10960q.png",
    "label": "Slovenian",
    "name": "Radio Murski Val 94.6",
    "url": "http://webradio.murskival.si:8000/listen.pls?sid=1"
  },
  {
    "bitrate": "128",
    "id": "s18092",
    "img": "http://cdn-radiotime-logos.tunein.com/s18092q.png",
    "label": "Sami Super Hiti!",
    "name": "Radio Net Fm Maribor 99.8",
    "url": "http://reflector.radionet.si:8000/stream.ogg"
  },
  {
    "bitrate": "128",
    "id": "s10601",
    "img": "http://cdn-radiotime-logos.tunein.com/s10601q.png",
    "label": "Slovenian",
    "name": "Radio Ognjišce 104.5",
    "url": "http://real.ognjisce.si:8000/ognjisce.mp3"
  },
  {
    "bitrate": "96",
    "id": "s9689",
    "img": "http://cdn-radiotime-logos.tunein.com/s9689q.png",
    "label": "Tvoji najljubši hiti",
    "name": "Radio Robin 99.5",
    "url": "http://live.radio.si/Robin"
  },
  {
    "bitrate": "32",
    "id": "s105310",
    "img": "http://cdn-radiotime-logos.tunein.com/s105310q.png",
    "label": "Slovenian",
    "name": "Radio Rogla 89.4",
    "url": "http://193.105.67.24:8010"
  },
  {
    "bitrate": "128",
    "id": "s123305",
    "img": "http://cdn-radiotime-logos.tunein.com/s123305q.png",
    "label": "Stran v izdelavi",
    "name": "Radio S 92.6",
    "url": "http://live4.infonetmedia.si/radios"
  },
  {
    "bitrate": "128",
    "id": "s9368",
    "img": "http://cdn-radiotime-logos.tunein.com/s9368q.png",
    "label": "Vedno blizu",
    "name": "Radio Sora 91.1",
    "url": "http://radio-sora.si:8000/radio-sora.mp3"
  },
  {
    "bitrate": "112",
    "id": "s106491",
    "img": "http://cdn-radiotime-logos.tunein.com/s106491q.png",
    "label": "Slovenian",
    "name": "Radio Sraka 94.6",
    "url": "http://193.105.67.24:8006"
  },
  {
    "bitrate": "128",
    "id": "s25182",
    "img": "http://cdn-radiotime-logos.tunein.com/s25182q.png",
    "label": "One of Europe's oldest and...",
    "name": "Radio Student 89.3",
    "url": "http://kruljo.radiostudent.si:8000/hiq"
  },
  {
    "bitrate": "128",
    "id": "s10362",
    "img": "http://cdn-radiotime-logos.tunein.com/s10362q.png",
    "label": "Radio Za Radovedne",
    "name": "Radio Triglav 96.0",
    "url": "http://live4.infonetmedia.si/Triglav"
  },
  {
    "bitrate": "128",
    "id": "s98796",
    "img": "http://cdn-radiotime-logos.tunein.com/s98796q.png",
    "label": "Slovenian",
    "name": "Radio Veseljak 94.9",
    "url": "http://195.95.158.131:9060"
  },
  {
    "bitrate": "32",
    "id": "s266964",
    "img": "http://cdn-radiotime-logos.tunein.com/s266964q.png",
    "label": "100% rock!",
    "name": "Rock Celje 97.7",
    "url": "http://live.rock-celje.si/RockCE"
  },
  {
    "bitrate": "56",
    "id": "s1386",
    "img": "http://cdn-radiotime-logos.tunein.com/s1386q.png",
    "label": "Luis Fonsi Ft. Demi Lovato - Echame La Culpa",
    "name": "Stajerski val 93.7",
    "url": "http://stream.stajerskival.si:8004"
  },
  {
    "bitrate": "128",
    "id": "s176287",
    "img": "http://cdn-radiotime-logos.tunein.com/s176287q.png",
    "label": "Slovenian",
    "name": "Radio 1 Koroska 105.0",
    "url": "http://live1.radio1.si/Radio1KOR"
  },
  {
    "bitrate": "128",
    "id": "s106467",
    "img": "http://cdn-radiotime-logos.tunein.com/s106467q.png",
    "label": "PRIMORSKI VAL je prva...",
    "name": "Radio Odmev 97.2",
    "url": "http://212.44.99.35:8000/stream"
  },
  {
    "bitrate": "128",
    "id": "s9586",
    "img": "http://cdn-profiles.tunein.com/s9586/images/logoq.jpg",
    "label": "Na Stirih Frekvencah",
    "name": "Radio Celje 95.1",
    "url": "http://89.142.196.111:9030/"
  },
  {
    "bitrate": "128",
    "id": "s232756",
    "img": "http://cdn-profiles.tunein.com/s9916/images/logoq.jpg",
    "label": "Pink Ft. Cash Cash - Can We Pretend",
    "name": "Radio Center 89.3",
    "url": "http://stream.radiocenter.si:80"
  },
  {
    "bitrate": "128",
    "id": "s106362",
    "img": "http://cdn-profiles.tunein.com/s106362/images/logoq.jpg?t=156232",
    "label": "Preko zelenih gričev se razlega prijazen glas",
    "name": "Radio Slovenske Gorice 96.4",
    "url": "http://46.105.43.31:8050/"
  },
  {
    "bitrate": "128",
    "id": "s10066",
    "img": "http://cdn-radiotime-logos.tunein.com/s10066q.png",
    "label": "Polni Pozitive",
    "name": "Radio Zeleni 93.1",
    "url": "http://stream77.pfe.technology:8000"
  },
  {
    "bitrate": "1",
    "img": "http://d1i6vahw24eb07.cloudfront.net/s164797q.png",
    "label": "Urbani radio",
    "name": "Radio Terminal",
    "url": "http://live.radioterminal.si"
  },
  {
    "bitrate": "128",
    "id": "s8674",
    "img": "http://cdn-radiotime-logos.tunein.com/s8674q.png",
    "label": "Z Veseljem Do Dobre Glasbe",
    "name": "Moj Radio 107.0",
    "url": "http://stream.strozak.org:8006"
  }
]