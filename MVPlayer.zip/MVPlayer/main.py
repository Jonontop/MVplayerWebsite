from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QHBoxLayout, QVBoxLayout, QStyle, QSlider, QFileDialog, QLabel, QComboBox, QLineEdit, QMessageBox, QInputDialog
import sys
from PyQt6.QtGui import QIcon
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
from PyQt6.QtMultimediaWidgets import QVideoWidget
from PyQt6.QtCore import Qt, QUrl, QTime, QTimer, QSettings
import pytubefix as pytube
import os
import random
from pytube import YouTube, Search
import barve, naloziscr, odpiranje, vrstica, shuffle, basicfunk, style, radio


height=600
width=900
class Okno(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowIcon(QIcon("MVPlayer.ico"))
        self.setWindowTitle("MVPlayer")
        self.setGeometry(500, 250, width, height)
        self.nekipac=0
        self.loopprzg=False
        self.zadnjagl=60

        self.spremeniglas = lambda v: basicfunk.spremeniglas(self, v)
        self.pohitrigumb = lambda: basicfunk.pohitrigumb(self)
        self.nehajpohitrigumb = lambda: basicfunk.nehajpohitrigumb(self)
        self.predvajajnazaj = lambda: basicfunk.predvajajnazaj(self)
        self.nazajgumb = lambda: basicfunk.nazajgumb(self)
        self.nehajnazajgumb = lambda: basicfunk.nehajnazajgumb(self)
        self.preskocipetino = lambda: basicfunk.preskocipetino(self)
        self.spremhit = lambda: basicfunk.spremhit(self)
        self.povecajfsc = lambda: basicfunk.povecajfsc(self)
        self.changepos = lambda pos: basicfunk.changepos(self, pos)
        self.predvajajvideo = lambda: basicfunk.predvajajvideo(self)
        self.prviframe = lambda status: basicfunk.prviframe(self, status)

        self.randomode = False
        self.shufflemg = shuffle.Shuffle(None, None, None, None, None, None, None)

        style.message()

        self.setStyleSheet("background-color: black;")
        
        self.naredi()
        self.sap()


    def naredi(self):
        self.mediaPlayer = QMediaPlayer()
        self.audioOutput = QAudioOutput()
        self.mediaPlayer.setAudioOutput(self.audioOutput)
        

        widget = QVideoWidget()

        #spodnja vrstica
        #Gumbi
        #odpri gumb
        self.odpri = QPushButton("Odpri datoteko")
        self.odpri.clicked.connect(lambda: (odpiranje.odpridatoteko(self, self.mediaPlayer, self.predvajaj, self.ffrwrd, self.nazaj, self.prespet, self.vrsta),setattr(self, 'randomode', False))) 
        style.odpri(self)
            
        #gumb za povecat
        self.povecaj= QPushButton()
        self.povecaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon))
        self.povecaj.clicked.connect(self.povecajfsc)
        style.povecaj(self)


        #Sliderji
        #slider za cas videa
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderMoved.connect(self.setpos)
        self.slider.setMaximumWidth(width)
        style.slider(self)
        
        #glasnost slider
        self.glasnost= QSlider(Qt.Orientation.Horizontal)
        self.glasnost.setRange(0,100)
        self.glasnost.setValue(60)
        self.glasnost.valueChanged.connect(self.spremeniglas)
        style.glasnost(self)
        
        #vrstica gumb
        self.vrstica = QPushButton()
        self.vrstica.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowUp))
        self.vrstica.clicked.connect(self.dodajvrsto)
        #self.vrstica.setStyleSheet(""" ... """)


        hbox = QHBoxLayout()
        hbox.setContentsMargins(0, 0, 0, 0)

        hbox.addWidget(self.odpri)
        hbox.addWidget(self.slider, 5)
        hbox.addWidget(self.glasnost, 1)
        hbox.addWidget(self.vrstica)
        hbox.addWidget(self.povecaj)

        #zgornja vrstica
        #URL downloader
        self.url = QLineEdit()
        self.url.setPlaceholderText("Vnesi youtube video URL ALI youtube playlist URL")
        style.url(self)

        #MP3 gumb
        self.dmp3 = QPushButton("MP3")
        self.dmp3.clicked.connect(lambda: self.nalozi("MP3"))
        style.dm3(self)
      
        #MP4 gumb
        self.dmp4 = QPushButton("MP4")
        self.dmp4.clicked.connect(lambda: self.nalozi("MP4"))
        style.dm4(self)
        
        #predvajaj gumb
        self.predvajaj = QPushButton()
        self.predvajaj.setEnabled(False)
        self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
        self.predvajaj.clicked.connect(self.predvajajvideo)
        style.predvajaj(self)
        
        #fastforward gumb
        self.ffrwrd=QPushButton()
        self.ffrwrd.pressed.connect(self.pohitrigumb)
        self.ffrwrd.released.connect(self.nehajpohitrigumb)
        self.ffrwrd.setEnabled(False)
        self.ffrwrd.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaSeekForward))
        style.ffrwrd(self)

        #nazaj gumb
        self.nazaj=QPushButton()
        self.nazaj.pressed.connect(self.nazajgumb)
        self.nazaj.released.connect(self.nehajnazajgumb)
        self.nazaj.setEnabled(False)
        self.nazaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaSeekBackward))
        style.nazaj(self)

        #cas
        self.cas = QLabel("00:00:00")
        self.cas.setStyleSheet("color: orange; font-size: 14px; font-weight: bold;")
        self.cas.setFixedWidth(75)

        #vrsta datoteke
        self.vrsta=QLabel("Ni datoteke")
        self.vrsta.setStyleSheet("color:orange; font-size:14px;")

        #preskoci petino videa gumb
        self.prespet=QPushButton()
        self.prespet.setEnabled(False)
        self.prespet.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaSkipForward))
        self.prespet.pressed.connect(self.preskocipetino)
        style.prespet(self)

        #hitrosti un choice al karkol
        self.hitrosti=QComboBox()
        self.hitrosti.addItems(["0.25x","0.5x","0.75x","1x","1.5x","2x","5x"])
        self.hitrosti.setCurrentText("1x")
        self.hitrosti.currentIndexChanged.connect(self.spremhit)
        style.hitrosti(self)

        self.shufflemg = shuffle.Shuffle(self.mediaPlayer,self.predvajaj,self.ffrwrd,self.nazaj,self.prespet,self.vrsta,self.style())

        upbox = QHBoxLayout()
        upbox.addWidget(self.vrsta)
        upbox.addWidget(self.url)
        upbox.addWidget(self.dmp3)
        upbox.addWidget(self.dmp4)
        upbox.addWidget(self.hitrosti)
        upbox.addWidget(self.nazaj)
        upbox.addWidget(self.predvajaj)
        upbox.addWidget(self.ffrwrd)
        upbox.addWidget(self.prespet)
        upbox.addWidget(self.cas)
        

        vbox = QVBoxLayout()
        vbox.setContentsMargins(5, 5, 5, 5)
        vbox.setSpacing(5)

        vbox.addLayout(upbox, 0)
        vbox.addWidget(widget, 1)
        vbox.addLayout(hbox, 0)
        
        self.mediaPlayer.setVideoOutput(widget)

        self.mediaPlayer.playbackStateChanged.connect(self.changestate)
        self.mediaPlayer.positionChanged.connect(self.changepos)
        self.mediaPlayer.durationChanged.connect(self.changedur)

        self.setLayout(vbox)

    def playr(self, index):
        if index > 0:
            url = self.radiocombox.currentData()
            self.mediaPlayer.stop()
            self.mediaPlayer.setSource(QUrl(url))
            self.predvajaj.setEnabled(True)
            self.ffrwrd.setEnabled(False)
            self.nazaj.setEnabled(False)
            self.prespet.setEnabled(False)
            self.vrsta.setText("Radio")
            self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
            self.mediaPlayer.play()
        else:
            self.mediaPlayer.stop()
            self.predvajaj.setEnabled(False)

    def refreshrs(self):
        if self.radiocombox.currentIndex() > 0:
            self.mediaPlayer.stop()
            self.mediaPlayer.setSource(QUrl(self.radiocombox.currentData()))
            self.mediaPlayer.play()

    def dodajvrsto(self):
        vrstica.dodajvrstico(self)

    def nasledn(self, kaj):
        self.randomode = False
        tren = self.mediaPlayer.source().toLocalFile()
        if not tren:
            return
        trendir = os.path.dirname(tren)
        trenfile = os.path.basename(tren)
        ex = (".m4a",".mp3",".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm")
        files = [f for f in os.listdir(trendir) if f.lower().endswith(ex)]
        files.sort()
        try:
            trenind = files.index(trenfile)
            nextind = (trenind + kaj) % len(files)
            next = os.path.join(trendir, files[nextind])
            self.mediaPlayer.setSource(QUrl.fromLocalFile(next))
            self.predvajaj.setEnabled(True)
            self.ffrwrd.setEnabled(True)
            self.nazaj.setEnabled(True)
            self.prespet.setEnabled(True)
            fileex = next.split('.')[-1].upper()
            self.vrsta.setText(f".{fileex}")
            self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
            self.mediaPlayer.play()    
        except ValueError:
            QMessageBox.critical(self, "Napaka", f"neki zjeban value")
        except IndexError:
            QMessageBox.critical(self, "Napaka", f"neki zjeban index")

    def sap(self):
        self.mediaPlayer.mediaStatusChanged.connect(self.chms)

    def chms(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            if hasattr(self, 'shufflemg') and self.shufflemg.randomode:
                self.shufflemg.playrs()
            elif self.loopprzg:
                self.mediaPlayer.setPosition(0)
                self.mediaPlayer.play()

    def togglerm(self):
        self.shufflemg.togglerm(self.shuffle)

    def random(self):
        self.shufflemg.playrs()

    def toggleloop(self):
        self.loopprzg = not self.loopprzg
        if self.loopprzg:
            try:
                self.loopgumb.setText("Loop On")
            except:
                pass
        else:
            try:
                self.loopgumb.setText("Loop Off")
            except:
                pass

    def checkloop(self, pos):
        if self.loopprzg and pos >=(self.mediaPlayer.duration()-40):
            self.mediaPlayer.setPosition(0)
            if self.mediaPlayer.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
                self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
            self.mediaPlayer.play()

    def changestate(self, state):
        if not (self.loopprzg and state == QMediaPlayer.PlaybackState.PlayingState and self.mediaPlayer.position() < 100):
            if state == QMediaPlayer.PlaybackState.PlayingState:
                self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
            else:
                self.predvajaj.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))

    def changedur(self, dur):
        self.slider.setRange(0, dur)

    def setpos(self,pos):
        self.mediaPlayer.setPosition(pos)

    def nalozi(self, format):
        url = self.url.text()
        if not url:
            QMessageBox.warning(self, "Napaka", "Vnesi veljaven URL!")
            return
        if "spotify.com" in url.lower():
            QMessageBox.critical(self, "Napaka", "Nj gre spotify v rit!")
        elif "youtube" in url.lower() or "youtu.be" in url.lower() or "yt" in url.lower():
            if "list" in url.lower():
                naloziscr.naloziytlist(self, url, format, self.mediaPlayer, self.predvajaj, self.ffrwrd, self.nazaj, self.prespet, self.vrsta)
            else:
                naloziscr.naloziyt(self, url, format, self.mediaPlayer, self.predvajaj, self.ffrwrd, self.nazaj, self.prespet, self.vrsta)
        else:
            QMessageBox.critical(self, "Napaka", "Nepodprt URL!")

    def keyPressEvent(self, event):
        if event.key()==Qt.Key.Key_D:
            self.mediaPlayer.setPosition(self.mediaPlayer.position() + 5000)
        elif event.key()==Qt.Key.Key_A:
            self.mediaPlayer.setPosition(max(0, self.mediaPlayer.position() - 5000))
        elif event.key()==Qt.Key.Key_P:
            self.predvajajvideo()
        elif event.key()==Qt.Key.Key_L:
            self.toggleloop()
        elif event.key()==Qt.Key.Key_F:
            self.povecajfsc()
        elif event.key()==Qt.Key.Key_Q:
            vrstica.dodajvrstico(self)
        elif event.key()==Qt.Key.Key_N:
            self.nasledn(1)
        elif event.key()==Qt.Key.Key_B:
            self.nasledn(-1)
        elif event.key()==Qt.Key.Key_O:
            odpiranje.odpridatoteko(self, self.mediaPlayer, self.predvajaj, self.ffrwrd, self.nazaj, self.prespet, self.vrsta),setattr(self, 'randomode', False)
        elif event.key()==Qt.Key.Key_R:
            self.random()
        elif event.key()==Qt.Key.Key_G:
            self.preskocipetino()
        elif event.key()==Qt.Key.Key_M:
            if self.glasnost.value()!=0:
                self.zadnjagl=self.glasnost.value()
                self.glasnost.setValue(0)
            else:
                self.glasnost.setValue(self.zadnjagl)
        elif event.key()==Qt.Key.Key_S:
            try:
                self.togglerm()
            except:
                pass
        elif event.key()==Qt.Key.Key_H:
            QMessageBox.information(self, "Pomoč", "Shortcuti:\n" 
            "D - skip 5 sec\n" \
            "A - nazaj 5 sec\n" \
            "P - ustavi\n" \
            "L - toggle loop\n" \
            "F - povecava na fullscreen\n" \
            "Q - vrstica z dodatnimi tooli\n" \
            "N - naslednji video v folderju\n" \
            "B - zadnji video v folderju\n" \
            "O - odpri datoteko\n" \
            "R - random video v folderju\n" \
            "G - preskoci petino videa\n" \
            "M - mute/unmute video\n" \
            "S - shuffle-pac neki da ti da random queue")
                


app = QApplication(sys.argv)
okno = Okno()
okno.show()

sys.exit(app.exec())