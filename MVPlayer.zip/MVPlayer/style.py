from PyQt6.QtWidgets import QApplication

def radiocombox(self):
    self.radiocombox.setStyleSheet("""
        QComboBox {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 3px;
            border-radius: 5px;
            min-width: 150px;
        }
        QComboBox::drop-down {
            border: 0px;
        }
        QComboBox QAbstractItemView {
            background-color: black;
            color: orange;
            selection-background-color: orange;
        }""")

def refreshrgumb(self):
    self.refreshrgumb.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width: 25px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")

def odpri(self):
    self.odpri.setStyleSheet("""
        QPushButton {
            background-color: transparent;
            color: orange;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            padding: 6px 12px;
        }
        QPushButton:hover {
            background-color: #E69500;
            color: white;
            padding: 5px 11px;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")

def povecaj(self):
    self.povecaj.setStyleSheet("""
        QPushButton {
            background-color: black;
            color: white;
            border: none;
            padding: 5px;
        }
        QPushButton:hover {
            background-color: #333;
        }
        QPushButton:pressed {
            background-color: #555;
        }""")
    
def slider(self):
    self.slider.setStyleSheet("""
        QSlider::groove:horizontal {
            background: 255;
            height: 8px;
            border-radius: 4px;
        }
        QSlider::handle:horizontal {
            background: orange;
            border: 2px solid #cc7a00;
            width: 18px;
            height: 18px;
            margin: -5px 0;
            border-radius: 9px;
        }
        QSlider::sub-page:horizontal {
            background: #ff9900;
            border-radius: 4px;
        }
        QSlider::add-page:horizontal {
            background: #222;
            border-radius: 4px;
        }""")

def glasnost(self):
    self.glasnost.setStyleSheet("""
        QSlider::groove:horizontal {
            background: #777;
            height: 8px;
            width: 120px;
            border-radius: 4px;
        }
        QSlider::handle:horizontal {
            background: #bbb;
            border: 2px solid #999;
            width: 8px;
            height: 8px;
            margin: -4px 0;
            border-radius: 8px;
        }
        QSlider::sub-page:horizontal {
            background: #999;
            border-radius: 4px;
        }
        QSlider::add-page:horizontal {
            background: #555;
            border-radius: 4px;
        }""")
    
def url(self):
    self.url.setStyleSheet("""
        QLineEdit {
            background-color: #222;
            color: orange;
            border: 2px solid orange;
            padding: 5px;
            border-radius: 5px;
        }""")
    
def dm3(self):
    self.dmp3.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }""")
    
def dm4(self):
    self.dmp4.setStyleSheet("""
        QPushButton {
                background-color: orange;
                color: black;
                font-size: 14px;
                padding: 5px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #E69500;
            }""")

def predvajaj(self):
    self.predvajaj.setStyleSheet("""
        QPushButton {
            background-color: orange;
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: #333;
            border: 2px solid black;
        }""")
    
def ffrwrd(self):
    self.ffrwrd.setStyleSheet("""
        QPushButton {
            background-color: orange;
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: #333;
            border: 2px solid black;
        }""")
    
def nazaj(self):
    self.nazaj.setStyleSheet("""
        QPushButton {
            background-color: orange;
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: #333;
            border: 2px solid black;
        }""")
    
def prespet(self):
    self.prespet.setStyleSheet("""
        QPushButton {
            background-color: orange;
            border: none;
            border-radius: 10px;
            max-width: 25px;
            max-height:20;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: #333;
            border: 2px solid black;
        }""")
    
def hitrosti(self):
    self.hitrosti.setStyleSheet("""
        QComboBox {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 3px;
            border-radius: 5px;
            max-width:48px;
        }
        QComboBox::drop-down {
            border: 0px;
        }
        QComboBox QAbstractItemView {
            background-color: black;
            color: orange;
            selection-background-color: orange;
        }""")
    
def loopgumb(self):
    self.loopgumb.setStyleSheet(""" 
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width:60px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")
    
def nasledngumb(self):
    self.nasledngumb.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width: 20px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")
    
def prejsngumb(self):
    self.prejsngumb.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width: 20px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")
    
def randomgumb(self):
    self.randomgumb.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width: 20px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")
    
def barvegumb(self):
    self.barvegumb.setStyleSheet("""
        QComboBox {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 3px;
            border-radius: 5px;
            min-width:60px;
        }
        QComboBox::drop-down {
            border: 0px;
        }
        QComboBox QAbstractItemView {
            background-color: black;
            color: orange;
            selection-background-color: orange;
        }""")
    
def shuffle(self):
    self.shuffle.setStyleSheet("""
        QPushButton {
            background-color: orange;
            color: black;
            font-size: 14px;
            padding: 5px;
            border-radius: 5px;
            max-width: 20px;
        }
        QPushButton:hover {
            background-color: #E69500;
        }
        QPushButton:pressed {
            background-color: orange;
        }""")

def message():
    QApplication.instance().setStyleSheet("""
        QMessageBox {
            background-color: white;
            color: white;
            font-size: 14px;
        }
        QMessageBox QLabel {
            color: white;
        }
        QMessageBox QPushButton {
            background-color: orange;
            color: white;
            border-radius: 5px;
            padding: 5px;
            min-width: 60px;
        }
        QMessageBox QPushButton:hover {
            background-color: white;
        }""")