from PyQt6.QtWidgets import QMessageBox, QFileDialog, QApplication
from PyQt6.QtCore import QUrl, QThread
import pytubefix as pytube
import os

def naloziytlist(self, url, format, mediaPlayer, predvajaj, ffrwrd, nazaj, prespet, vrsta):
    try:
        #playlist
        playlist = pytube.Playlist(url)
        folder = QFileDialog.getExistingDirectory(self, "Izberi mapo za prenos")
        if not folder:
            return
        folder =os.path.join(folder, playlist.title)
        os.makedirs(folder, exist_ok=True)
        psize=0
        psize = 0
        for video in playlist.videos:
            try:
                if format == "MP3" or format=="mp3":
                    stream = video.streams.filter(only_audio=True).first()
                else:
                    stream = video.streams.filter(progressive=True).order_by("resolution").desc().first()
                psize += stream.filesize if stream else 0
            except:
                continue
        if psize > 1024*1024*1024:
            psize = f"{psize/(1024*1024*1024):.2f} GB"
        else:
            psize = f"{psize/(1024*1024):.2f} MB"
        QMessageBox.information(self, "Prenos", f"Playlist: {playlist.title}\nŠtevilo videov: {len(playlist.videos)}\nVelikost filea: {psize}\nPrenos v teku...")  
        prvivid= None
        for i, video in enumerate(playlist.videos):
            try:
                if format == "MP3":
                    stream = video.streams.filter(only_audio=True, file_extension='mp4').first()
                    if not stream:
                        raise Exception("Ni audio streama")
                    temp_file = stream.download(output_path=folder)
                    base, ext = os.path.splitext(temp_file)
                    imedatoteke = base + '.mp3'
                    os.rename(temp_file, imedatoteke)
                else:
                    stream = video.streams.filter(progressive=True).order_by("resolution").desc().first()
                    imedatoteke = stream.download(folder)
                if i == 0:
                    prvivid = imedatoteke    
            except Exception as e:
                QMessageBox.warning(self, "Opozorilo", f"Napaka pri prenosu videja {video.title}: {str(e)}")
                continue    
        QMessageBox.information(self, "Konec", f"Vsi videi so preneseni! preneseni so v mapo {playlist.title}, v izbranem pathu:\n{folder}")
        if prvivid:
            try:
                mediaPlayer.mediaStatusChanged.disconnect(self.prviframe)
            except TypeError:
                pass   
            mediaPlayer.setSource(QUrl.fromLocalFile(prvivid))
            predvajaj.setEnabled(True)
            ffrwrd.setEnabled(True)
            nazaj.setEnabled(True)
            prespet.setEnabled(True)
            fileex = prvivid.split('.')[-1].upper()
            vrsta.setText(f".{fileex}")
            mediaPlayer.mediaStatusChanged.connect(self.prviframe)
        return
    except Exception as e:
        QMessageBox.critical(self, "Napaka", f"Napaka pri prenosu: {str(e)}")

def naloziyt(self, url, format, mediaPlayer, predvajaj, ffrwrd, nazaj, prespet, vrsta):
    try:
        yt = pytube.YouTube(url)
        folder = QFileDialog.getExistingDirectory(self, "Izberi mapo za prenos")
        if not folder:
            return
        QMessageBox.information(self, "Prenos", f"Naslov: {yt.title}\nPrenos v teku...")
        if format=="MP3":
            stream=yt.streams.filter(only_audio=True).first()
        else:
            stream = yt.streams.filter(progressive=True).order_by("resolution").desc().first()
        imedatoteke = stream.download(folder)
        QMessageBox.information(self, "Uspeh", "Prenos končan!")
        if imedatoteke:
            try:
                mediaPlayer.mediaStatusChanged.disconnect(self.prviframe)
            except TypeError:
                pass   
            mediaPlayer.setSource(QUrl.fromLocalFile(imedatoteke))
            predvajaj.setEnabled(True)
            ffrwrd.setEnabled(True)
            nazaj.setEnabled(True)
            prespet.setEnabled(True)
            fileex = imedatoteke.split('.')[-1].upper()
            vrsta.setText(f".{fileex}")
            mediaPlayer.mediaStatusChanged.connect(self.prviframe)
    except Exception as e:
        QMessageBox.critical(self, "Napaka", f"Napaka pri prenosu: {e}")