from PyQt6.QtWidgets import QMessageBox, QApplication
from PyQt6.QtCore import QUrl
import os
import random

class Shuffle:
    def __init__(self, mediaPlayer, predvajaj, ffrwrd, nazaj, prespet, vrsta, style):
        self.mediaPlayer = mediaPlayer
        self.predvajaj = predvajaj
        self.ffrwrd = ffrwrd
        self.nazaj = nazaj
        self.prespet = prespet
        self.vrsta = vrsta
        self.style = style
        self.randomode = False
        self.napredvajane = None
        self.shufflegumb = None

    def togglerm(self, shufflegumb=None):
        if shufflegumb:
            self.shufflegumb = shufflegumb
        self.randomode = not self.randomode
        if self.shufflegumb:
            self.shufflegumb.setText("On" if self.randomode else "Off")
        if self.randomode:
            self.playrs()
        elif hasattr(self, 'napredvajane'):
            del self.napredvajane

    def playrs(self):
        tren = self.mediaPlayer.source().toLocalFile()
        if not tren:
            self.sm("Napaka", "Ni naloženega videa!")
            if self.shufflegumb:
                self.shufflegumb.setText("Off")
            self.randomode = False
            return False

        try:
            trendir = os.path.dirname(tren)
            ex = (".m4a", ".mp3", ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm")
            files = [f for f in os.listdir(trendir) if f.lower().endswith(ex)]  
            if not files:
                self.sm("Napaka", "V mapi ni video datotek!")
                return False
            if self.randomode:
                if not hasattr(self, 'napredvajane') or not self.napredvajane:
                    self.napredvajane = files.copy()
                    if tren:
                        trenfn = os.path.basename(tren)
                        if trenfn in self.napredvajane:
                            self.napredvajane.remove(trenfn)
                if not self.napredvajane:
                    self.napredvajane = files.copy()
                    if tren:
                        trenfn = os.path.basename(tren)
                        if trenfn in self.napredvajane:
                            self.napredvajane.remove(trenfn)  
                randomf = random.choice(self.napredvajane)
                self.napredvajane.remove(randomf)
            else:
                randomf = random.choice(files)
            randomp = os.path.join(trendir, randomf)
            self.mediaPlayer.stop()
            self.mediaPlayer.setSource(QUrl.fromLocalFile(randomp))
            self.predvajaj.setEnabled(True)
            self.ffrwrd.setEnabled(True)
            self.nazaj.setEnabled(True)
            self.prespet.setEnabled(True)
            fileex = randomp.split('.')[-1].upper()
            self.vrsta.setText(f".{fileex}")
            self.predvajaj.setIcon(self.style.standardIcon(self.style.StandardPixmap.SP_MediaPause))
            self.mediaPlayer.play()
            return True          

            
        except Exception as e:
            self.sm("Napaka", f"Napaka pri nalaganju: {str(e)}")
            return False

    def sm(self, title, message):

        msg = QMessageBox()
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setStyleSheet("""
            QMessageBox {
                background-color: black;
                color: white;
                font-size: 14px;
            }
            QMessageBox QLabel {
                color: white;
            }
            QMessageBox QPushButton {
                background-color: orange;
                color: black;
                border-radius: 5px;
                padding: 5px;
                min-width: 60px;
            }
            QMessageBox QPushButton:hover {
                background-color: #E69500;
            }""")
        msg.exec()